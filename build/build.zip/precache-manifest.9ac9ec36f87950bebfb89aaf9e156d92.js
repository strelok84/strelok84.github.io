self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "39a4acc6387b0ba6216897a621250498",
    "url": "/streloc84.github.io/index.html"
  },
  {
    "revision": "4b2c979ac2e7d09002c5",
    "url": "/streloc84.github.io/static/css/main.52439501.chunk.css"
  },
  {
    "revision": "d0bba1822054837bbea9",
    "url": "/streloc84.github.io/static/js/2.dde64cec.chunk.js"
  },
  {
    "revision": "8de4bdbb127f280cc6b79279dd69f244",
    "url": "/streloc84.github.io/static/js/2.dde64cec.chunk.js.LICENSE"
  },
  {
    "revision": "4b2c979ac2e7d09002c5",
    "url": "/streloc84.github.io/static/js/main.12e8313e.chunk.js"
  },
  {
    "revision": "ec46f61669cf277dd387",
    "url": "/streloc84.github.io/static/js/runtime-main.9cecdb52.js"
  },
  {
    "revision": "f38166e0bcbb7663f0d2834ffd52addf",
    "url": "/streloc84.github.io/static/media/b52_[allfont.ru].f38166e0.ttf"
  },
  {
    "revision": "37ae3287f1a6936c946700be07ff67a3",
    "url": "/streloc84.github.io/static/media/paper_clip.37ae3287.svg"
  },
  {
    "revision": "3c0f6fd6628902b2a8f2a3021b8862d5",
    "url": "/streloc84.github.io/static/media/textured_paper.3c0f6fd6.png"
  }
]);